# cMcPAT - COSSIM-modified McPAT version.

Please see individual files for details of the license on each file.

The preferred license can be found in [LICENSE](LICENSE).


All files in this distribution have licenses based on the BSD or BSD-compatible licenses.  

The copyright holders include :

Copyright (c) 2012 The Hewlett-Packard Development Company, L.P.

Also some files from Daya Khudia's GEM5toMcPAT tool have been used. Credits to [GEM5toMcPAT](https://bitbucket.org/dskhudia/gem5tomcpat).
